Nitanum Nuker V3",
            "hello there fucking faggo",
            "@hzmicid",
            "notspeezy"
        ],
        "roles_name": [
            "L wizzed by Nitanum Nuker",
            "Nitanum Nuker owns u",
            "Nitanum Nuker runs u"
        ],
        "messages_content": [
            "@everyone fuck all Nitanum Nuker",
            "@everyone Nitanum Nuker runs u",
            "@everyone Nitanum Nuker running cord"
        ]
    }
}